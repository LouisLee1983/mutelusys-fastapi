# -*- coding: utf-8 -*-
"""
AI助手模块
""" 