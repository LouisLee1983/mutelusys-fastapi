from app.localization.models import Currency

# 引用主模型中的Currency类，保持一致性
# 这样可以通过from app.localization.currency.models import Currency来引用
# 满足项目的模块化组织要求
