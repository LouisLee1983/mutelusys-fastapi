from app.localization.models import Language

# 引用主模型中的Language类，保持一致性
# 这样可以通过from app.localization.language.models import Language来引用
# 满足项目的模块化组织要求
